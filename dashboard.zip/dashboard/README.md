# Dashboard with HTML and CSS 

Build a responsive dashboard using HTML and CSS, featuring a toggleable sidebar and functional navbar. The design is clean, modern, and user-friendly, ensuring seamless navigation and optimal viewing on all devices.

[![youtube](https://img.shields.io/badge/YouTube-red?style=for-the-badge&logo=youtube&logoColor=white)](https://youtu.be/-efFsgnfLXI)

![Logo](https://raw.githubusercontent.com/codzsword/dashboard-with-html-and-css/main/demo-dashboard-html-css.png)

